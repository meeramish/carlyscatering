/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarlysCatering;

/**
 *
 * @author meera mishra
 */
public class Coordinator extends Employee {
    public Coordinator (){
        super();
        
    }
    @Override
    public void setPayRate(){
        this.payRate=20;
         
    }

    @Override
    public void setJobTitle() {
        this.jobTitle="Coordinator";
        
    
}
}
