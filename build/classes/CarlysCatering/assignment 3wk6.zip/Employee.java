/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarlysCatering;

/**
 *
 * @author meera mishra
 */
public abstract class Employee {
    String employeeID;
    String lastName;
    String firstName;
    protected double payRate;
    protected String jobTitle;
    
    public Employee() {
        setJobTitle();
        setPayRate();
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public double getPayRate() {
        return payRate;
    }

    

    public String getJobTitle() {
        return jobTitle;
    }

    public abstract void setJobTitle() ;
    
    public abstract void setPayRate();
        
}
