package CarlysCatering;

import static CarlysCatering.DinnerEventdemo.getEventNumber;
import static CarlysCatering.DinnerEventdemo.getGuests;
import static CarlysCatering.DinnerEventdemo.getPhoneNumber;
import java.util.Scanner;

/**
 *
 * @author meera mishra
 */
public class StaffDinnerEvent {

    public static void main(String[] args) {
        DinnerEvent adinnerEvent = new DinnerEvent();
        String eventNum = getEventNumber();
        int guests = getGuests();
        int waitstaff = 0;
        int bartender = 0;

        String phoneNumber = getPhoneNumber();
        adinnerEvent.setEventNumber(eventNum);
        adinnerEvent.setGuests(guests);
        adinnerEvent.setPhoneNumber(phoneNumber);

        System.out.print("Enter dinner choice for event:");
        System.out.print("please enter entree choice :");
        Scanner input = new Scanner(System.in);
        int entree = input.nextInt();
        
        System.out.print("please enter sidedish1 choice :");
        int sideDish1 = input.nextInt();
        
        System.out.print("please enter sidedish2 choice :");
        int sideDish2 = input.nextInt();
         
        System.out.print("please enter dessert choice :");
        int dessert = input.nextInt();
       
        adinnerEvent.setEntree(entree);
        adinnerEvent.setSideDish1(sideDish1);
        adinnerEvent.setSideDish2(sideDish2);
        adinnerEvent.setDessert(dessert);
        waitstaff = 1 + guests / 10;
        int x = 0; // use for employee array index
        bartender = 1 + guests/25;
        

        // setting waitstaff employees
        Employee[] empList = new Employee[15];
        for ( ; x < waitstaff; x++) {
            empList[x] = new Waitstaff();
        }
        
        // setting bartenders
       for ( ; x < (x + bartender); x++) {
            empList[x] = new Bartender();
        }  
        
        empList[x] = new Coordinator();
        adinnerEvent.setEmployeeList(empList);
        
        displayDetails(adinnerEvent);
    }

    public static String getPhoneNumber() {
        String phoneNumber;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter phone number >> ");
        phoneNumber = input.nextLine();
        return phoneNumber;
    }

    public static String getEventNumber() {
        String num;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter event number >> ");
        num = input.nextLine();
        return num;
    }

    public static int getGuests() {
        int guests;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of guests >> ");
        guests = input.nextInt();
        input.nextLine();
        return guests;

    }
    
    public static void displayDetails(DinnerEvent e) {  //Change the constant price with the method
        System.out.println("\nEvent #" + e.getEventNumber());
        System.out.println("The price for an event with " + e.getGuests()
                + " guests at $" + e.getPricePerGuest() + " per guest is $" + e.getPrice());
        System.out.println("Phone number: " + e.getPhoneNumber());
        System.out.println("Menu : " + e.getMenu());
        System.out.println("Employee Assigned:");
        Employee[] empList = e.getEmployeeList();
        for(int x=0; x<empList.length; x++ ){
            if(empList[x] != null){
                System.out.println("Employee[" + (x+1) + "]" + empList[x].getJobTitle() );
            } 
        }

    }
}
