package CarlysCatering;

public class Event {

    private double pricePerGuest;// Added a new variable price per guest.
    public final static double LOWERGUEST_PRICE = 32.00;// Replaced higher and lower
    public final static double HIGHGUEST_PRICE = 35.00;
    public final static int LARGE_EVENT = 50;
    private String eventNumber;
    private int guests;
    private double price;
    private String phoneNumber;

    public boolean isLargeEvent() {//method isLargeevent created returning true and false.
        if (guests >= 50) {
            return true;
        } else {
            return false;
        }

    }

    public double getPricePerGuest() { // the public method to return its value.
        return pricePerGuest;
    }

    public Event() {
        this("A000", 0 ,"0000000000");
    }

    public Event(String num, int guests, String phoneNumber) {
        setEventNumber(num);
        setGuests(guests);
        setPhoneNumber(phoneNumber);
    }

    public void setEventNumber(String num) {
        char achar = 0;
        if ((num.length() == 4) && Character.isLetter(num.charAt(0))//converting to 4 digit
                && (Character.isDigit(num.charAt(1)))
                && (Character.isDigit(num.charAt(2)))) {
            eventNumber = num.toUpperCase(); // As only first character is letter

            System.out.println("The event number: " + eventNumber);

        } else {
            eventNumber = "A000";
            System.out.println("The event number is :" + eventNumber);
        }

    }

    public void setGuests(int gsts) {  //price set according to lower and higher guest price.
        guests = gsts;
        if (isLargeEvent()) {
            pricePerGuest = LOWERGUEST_PRICE;
        } else {
            pricePerGuest = HIGHGUEST_PRICE;
        }
        price = guests * pricePerGuest; //Total event price.

    }

    public void setPhoneNumber(String num) {
        StringBuilder phoneSb = new StringBuilder();

        for (int x = 0; x < num.length(); x++) {
            if (Character.isDigit(num.charAt(x))) {
                phoneSb.append(num.charAt(x));
            }

        }
        
        if(phoneSb.toString().length() == 10){ // using toString method of StringBuilder to convert phoneSb into String
            this.phoneNumber = phoneSb.toString();
        }
        else{
            this.phoneNumber = "0000000000";
        }
    }
    public String getPhoneNumber(){
       
        StringBuilder phoneSb = new StringBuilder(this.phoneNumber);
        phoneSb.insert(0, '(');
        phoneSb.insert(4, ')');
        phoneSb.insert(8, '-');
        System.out.println("The phone number is: ");
        return phoneSb.toString(); //Converting phoneSb string builder to string.
    }

    public String getEventNumber() {

        return eventNumber;
    }

    public int getGuests() {
        return guests;
    }

    public double getPrice() {
        return price;
    }
}
