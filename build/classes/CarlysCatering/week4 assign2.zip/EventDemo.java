package CarlysCatering;

import java.util.Scanner;

public class EventDemo {

    public static void main(String[] args) {
        String eventNum;
        String phoneNumber;
        int guests;
        eventNum = getEventNumber();
        guests = getGuests();
        phoneNumber = getPhoneNumber();
        Event e1 = new Event(eventNum, guests, phoneNumber);  
        eventNum = getEventNumber();
        guests = getGuests();
        phoneNumber = getPhoneNumber();
        Event e2 = new Event(eventNum, guests, phoneNumber);
        eventNum = getEventNumber();
        guests = getGuests();
        phoneNumber = getPhoneNumber();
        Event e3 = new Event(eventNum, guests, phoneNumber);  // A new method added the phonenumber

        displayDetails(e1);
        displayDetails(e2);
        displayDetails(e3);
        
        compareEvent(e1, e2); // To compare the event based on number of guests.
        compareEvent(e1, e3);
        compareEvent(e2, e3);
    }
     public static String getPhoneNumber() {
        String phoneNumber;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter phone number >> ");
       phoneNumber = input.nextLine();
        return phoneNumber;
    }

    public static String getEventNumber() {
        String num;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter event number >> ");
        num = input.nextLine();
        return num;
    }

    public static int getGuests() {
        int guests;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of guests >> ");
        guests = input.nextInt();
        input.nextLine();
        return guests;
    }

    public static void displayDetails(Event e) {  //Change the constant price with the method
        System.out.println("\nEvent #" + e.getEventNumber());
        System.out.println("The price for an event with " + e.getGuests()
                + " guests at $" + e.getPricePerGuest() + " per guest is $" + e.getPrice());
        System.out.println("Phone number: " + e.getPhoneNumber());
        System.out.println("Whether this is a large event is "
                + e.isLargeEvent()); //A new method using isLargeEvent.
       
    }
    public static Event compareEvent(Event event1, Event event2){
        System.out.println("First Event - Event #" + event1.getEventNumber() + ", Number of guests: " + event1.getGuests());
        System.out.println("Second Event - Event #" + event2.getEventNumber() + ", Number of guests: " + event2.getGuests());
        if(event1.getGuests()>event2.getGuests())
        {
           System.out.println("Larger Event - Event #" + event1.getEventNumber() + ", Number of guests: " + event1.getGuests()); 
           return event1;
        }
        else{
            System.out.println("Larger Event - Event #" + event2.getEventNumber() + ", Number of guests: " + event2.getGuests()); 
            return event2;
        }
        
        
    }
}
