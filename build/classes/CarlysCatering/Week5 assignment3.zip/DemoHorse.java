/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meera mishra
 */
import javax.swing.JOptionPane;
public class DemoHorse {
    public static void main(String[] args){
       Horse aHorse= new Horse();
       RaceHorse aRaceHorse = new RaceHorse();
       
       aHorse.setName();
       aHorse.setColor();
       aHorse.setBirthYear();
       
       aRaceHorse.setNumberRaces();
       
       JOptionPane.showMessageDialog(null,"The name of the horse is :" + aHorse.getName()+" ,"
               + "The horses color is: " + aHorse.getColor()+" ," + "The hoses birth year is: " + 
               aHorse.getBirthYear()+" ," + " number of races is :"+  aRaceHorse.getNumberRaces() );
    }
    
    
}
