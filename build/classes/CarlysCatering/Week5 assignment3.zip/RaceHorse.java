/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meera mishra
 */
import javax.swing.JOptionPane;
public class RaceHorse extends Horse {
    private String numberRaces;
    
    public void setNumberRaces(){
        numberRaces = JOptionPane.showInputDialog(null," enter number of the horse races:");
    }
    public String getNumberRaces(){
        return numberRaces;
    }
    
}
