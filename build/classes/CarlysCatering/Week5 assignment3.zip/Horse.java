/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meera mishra
 */
import javax.swing.JOptionPane;
public class Horse {
    private String name;
    private String color;
    private String birthYear;
    
    public void setName(){
        name = JOptionPane.showInputDialog(null,"Please enter name of the horse:");
    }
   public String getName(){
       return name;
   } 
   public void setColor() {
       color = JOptionPane.showInputDialog(null,"Please enter color of the horse:");
   }
   
   public String getColor() {
       return color;
   }
  public void setBirthYear() {
      birthYear=JOptionPane.showInputDialog(null,"Please enter birth year of the horse:");
  }
  public String getBirthYear(){
      return birthYear;
  }
}
