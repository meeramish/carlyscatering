
import java.util.Scanner;

public class DemoTennisGame {

    public static void main(String[] args) {
        String player1;
        String player2;
        int score1;
        int score2;
        String partner1;
        String partner2;
        
        
        // Setting single tennis game
        TennisGame aTennisGame = new TennisGame();
        
        System.out.println("Enter Single Tennis game details:");
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter player 1's name >> ");
        player1 = keyboard.nextLine();
        aTennisGame.setPlayer1(player1);
        
        System.out.print("Enter player 2's name >> ");
        player2 = keyboard.nextLine();
        aTennisGame.setPlayer2(player2);
 
        System.out.print("Enter " + player1 + "'s score >> ");
        score1 = keyboard.nextInt();
        aTennisGame.setScore1(score1);
        
        System.out.print("Enter " + player2 + "'s score >> ");
        score2 = keyboard.nextInt();
        aTennisGame.setScore2(score2);

        System.out.println("Enter Double Tennis game details:");
        DoubleTennisGame aDoubleTennisGame = new DoubleTennisGame();
        
        System.out.print("Enter player 1's name >> ");
        player1 = keyboard.nextLine();
        aDoubleTennisGame.setPlayer1(player1);
        
        System.out.print("Enter player 2's name >> ");
        player2 = keyboard.nextLine();
        aDoubleTennisGame.setPlayer2(player2);
        
        System.out.print("Enter partner1 name >> ");
        partner1 = keyboard.nextLine();
        aDoubleTennisGame.setPartner1(partner1);
        

        System.out.print("Enter partner2 name >> ");
        partner2 = keyboard.nextLine();
        aDoubleTennisGame.setPartner2(partner2);
        
        System.out.print("Enter " + player1 + "'s score >> ");
        score1 = keyboard.nextInt();
        aDoubleTennisGame.setScore1(score1);
        
        System.out.print("Enter " + player2 + "'s score >> ");
        score2 = keyboard.nextInt();
        aDoubleTennisGame.setScore2(score2);
        

        display(aTennisGame);
        display(aDoubleTennisGame);
    }
    
    public static void display(TennisGame game){
       System.out.println("Player1: " + game.getPlayer1() + " - Score : " + game.getFinalScore1());
       System.out.println("Player2: " + game.getPlayer2() + "- Score : " + game.getFinalScore2());
    }
    
    public static void display(DoubleTennisGame game){
       System.out.println("Players: " + game.getPlayer1() + "/" + game.getPartner1() + " - Score : " + game.getFinalScore1());
       System.out.println("Player2: " + game.getPlayer2() + "/" + game.getPartner2() + "- Score : " + game.getFinalScore2());
    }
}
