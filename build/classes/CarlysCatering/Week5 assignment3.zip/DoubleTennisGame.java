/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meera mishra
 */
public class DoubleTennisGame extends TennisGame {

    private String partner1;
    private String partner2;

    public String getPartner1() {  //partner of the players
        return partner1;
    }

    public String getPartner2() {
        return partner2;
    }

    public void setPartner1(String name) {
        partner1 = name;
    }

    public void setPartner2(String name) {
        partner1 = name;
    }


}
