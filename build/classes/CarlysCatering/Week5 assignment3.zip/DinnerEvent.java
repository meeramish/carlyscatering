/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarlysCatering;

import java.util.Arrays;

/**
 *
 * @author meera mishra
 */
public class DinnerEvent extends Event {

    int entree;
    int sideDish1;
    int sideDish2;
    int dessert;
    String entreeOptions[] = {"salad, sandwich, pizza"};
    String sideDishOptions[] = {"rolls, fritters, beans"};
    String dessertOptions[] = {"icecream, cheesecake, donuts"};

    public DinnerEvent(String eventNumber, int guests, int entree, int sideDish1, int sideDish2, int dessert) {
        super(eventNumber, guests, null, 0);
        setEntree(entree);
        
    }

    public int getEntree() {
        return entree;
    }

    public void setEntree(int entree) {
        this.entree = entree;
    }

    public int getSideDish1() {
        return sideDish1;
    }

    public void setSideDish1(int sideDish1) {
        this.sideDish1 = sideDish1;
    }

    public int getSideDish2() {
        return sideDish2;
    }

    public void setSideDish2(int sideDish2) {
        this.sideDish2 = sideDish2;
    }

    public int getDessert() {
        return dessert;
    }

    public void setDessert(int dessert) {
        this.dessert = dessert;
    }
    public String getMenu(){
     String menu =  " Menu options : " +"\n" 
             + "Entree: " + "\n"
             + Arrays.toString(entreeOptions) + "\n" + "Side dishes : " + 
             "\n" +  Arrays.toString(sideDishOptions) + "\n" + "Dessert:" + 
             "\n" + Arrays.toString(dessertOptions);
            return menu ;
        
    }
    
    


}
 