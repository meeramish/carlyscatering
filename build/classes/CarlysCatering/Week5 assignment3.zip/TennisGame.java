/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meera mishra
 */
public class TennisGame {

    private String player1;
    private String player2;
    private int score1;
    private int score2;
    private String finalScore1;
    private String finalScore2;
    private String SCORE_NAMES[] = {"love", "15", "30", "40", "game"};

    public String getPlayer1() {
        return player1;
    }

    public String getPlayer2() {
        return player2;
    }

    public int getScore1() {
        return score1;
    }

    public int getScore2() {
        return score1;
    }

    public String getFinalScore1() {
        return finalScore1;
    }

    public String getFinalScore2() {
        return finalScore2;
    }

    public void setPlayer1(String name) {
        player1 = name;
    }

    public void setPlayer2(String name) {
        player2 = name;
    }

    public void setScore1(int num) {

        if (num > 4 || num < 0 ) {
            score1 = 0;
            setFinalScore1("error");
        }
        else {
            score1 = num;
            setFinalScore1(SCORE_NAMES[num]);
        }  
        
        if(score1 == 4 && score2 == 4){
            score1 = 0;
            score2 = 0;
            setFinalScore1("error");
            setFinalScore2("error");
        }
    }

    public void setScore2(int num) {
        if (num > 4 || num < 0 ) {
            score2 = 0;
            setFinalScore2("error");
        }
        else {
            score2 = num;
            setFinalScore2(SCORE_NAMES[num]);
        } 
        
                
        if(score1 == 4 && score2 == 4){
            score1 = 0;
            score2 = 0;
            setFinalScore1("error");
            setFinalScore2("error");
        }

    }

    public void setFinalScore1(String f1Final) {
        this.finalScore1 = f1Final;
    }
    public void setFinalScore2(String f2Final){
        this.finalScore2= f2Final;
    }
    

}
